---
title: Die TUBAF-Thesis Klasse
author: Max Weiner
date: 2024-04-18
---

Die `tubaf-thesis` ist eine Klasse für Abschlussarbeiten wie Bachelor-, Master-, Diplom- und Doktorarbeiten. Die Kalsse
ist von `tubaf-report` abgeleitet und erweitert diese durch eine anpasste Titelseite und zusätzliche Makros.
Die Titelseite orientiert sich dabei an den Anforderungen der Promotionsordnungen, ist aber auch für Diplom-, Bachelor- oder Masterarbeiten verwendbar.
`tubaf-report` ist selbst von der KOMA-Script Klasse `scrreprt` abgeleitet und unterstützt dessen komplette
Funktionalität, wie in
deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass[<options>]{tubaf-thesis}
```

## Klassenoptionen

`approved=true/false`
: Gibt an, ob die Arbeit bereits genehmigt/geprüft wurde. Dies beeinflusst einige Textbausteine auf der Titelseite.

## Bereitgestellte Befehle

### Dokument-Metadaten

`\supervisor{<name>}`
:   Setze `<name>` als Betreuer auf der Titelseite.

`\supervisors{<name1> \and <name2> \and ...}`
:   Setze die gegebenen Namen als Betreuer auf der Titelseite. Die einzelnen Namen werden durch `\and`, wie es von  `\author{}` gewohnt ist.

`\examiners{<name1> \and <name2> \and ...}`
:   Setze die gegebenen Namen als Prüfer auf der Titelseite. Die einzelnen Namen werden durch `\and`, wie es von  `\author{}` gewohnt ist.

`\reviewers{<name1> \and <name2> \and ...}`
:   Setze die gegebenen Namen als Gutachter auf der Titelseite (anstelle von Prüfern bei Dissertationen). Die einzelnen Namen werden durch `\and`, wie es von  `\author{}` gewohnt ist.

`\course{<name>}`
:   Setze `<name>` als Studiengang auf der Titelseite.

`\faculty{<name>}`
: Setzt den Namen der Fakultät, bei welcher diese Arbeit eingereicht oder durch welche diese genehmigt wurde auf der Titelseite.

`\currentdegree{<grad>}`
:   Setzt den aktuellen akademischen Grad des Autors/der Autorin auf der Titelseite vor dessen/deren Namen.

`\attaineddegree[<kurzform>]{<grad>}`
:   Setzt den mit dieser Arbeit angestrebten akademischen Grad auf der Titelseite. Eine optionale Kurzform wird in Klammern hinter der Langform gesetzt.

`\birthdate{<datum>}`
:   Setzt das Geburtsdatum des Autors/der Autorin auf der Titelseite.

`\birthplace{<ort>}`
:   Setzt den Geburtsort des Autors/der Autorin auf der Titelseite.

Geerbt von `tubaf-logo`, aber im besonderen nützlich für diese Klasse:

`\logo{<image>}`
:   Nutze das Bild `<image>` als Zweitlogo, welches am oberen rechten Rand der Titelseite gesetzt wird (z.B. Logo des Instituts oder Projektes).

Die Art der Arbeit (Dissertation, Diplomarbeit, ...) sollte mit `\subject` gesetzt werden.

### Hilfsmakros

`\makedeclarationofauthorship[<date>]`
:   Setze eine Seite für die vorgeschriebene Selbstständigkeitserklärung mit einem Unterschriftenfeld für den Autor (Kurzversion)
    mit dem Datum `<date>`.
    `<date>` ist optional (Voreinstellung `\today`, also aktuelles Datum).

# Anmerkungen zur Implementierung

Die Klasse nutzt den `\titlefoot` und `\moretitle` Befehle, welcher von `tubaf-title` bereitgestellt werden, um die zusätzlichen Metadaten in die Titelseite einzufügen.
Nutzen Sie diese nicht selbst im Dokument, da sonst die von dieser Klasse gemachten Änderungen überschrieben würden.
Die Beschriftungen der Metadaten auf der Titelseite und die Selbstständigkeitserklärung passen sich an die Spracheinstellung von Paketen wie `babel` an.
Es werden die Sprachen `english` und `ngerman` unterstützt.

