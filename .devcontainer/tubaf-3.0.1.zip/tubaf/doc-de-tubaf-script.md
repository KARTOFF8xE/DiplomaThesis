---
title: Die TUBAF-Script Klasse
author: Marcus Herbig
date: 2024-04-18
---

Die `tubaf-script` ist eine Klasse für Vorlesungs-, Übungs- und Praktikumsskripte. Die Klasse ist von `tubaf-report` abgeleitet und erweitert diese durch eine anpasste Titelseite.
`tubaf-report` is selbst von der KOMA-Script Klasse `scrreprt` abgeleitet und unterstützt dessen komplette Funktionalität, wie in deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass[<options>]{tubaf-script}
```

## Klassenoptionen

Die Klasse unterstützt aktuell keine neuen Optionen.

## Bereitgestellte Befehle

`\module[<short>]{<module>}`
: Name des Moduls, für welches das Script bereitgestellt wird. Über das optionale Argument kann eine Kurzform angegeben werden.

`\course[<short>]{<course>}`
: Name des Studiengangs, welcher das Modul beinhaltet. Über das optionale Argument kann eine Kurzform angegeben werden.

`\semester[<short>]{<semester>}`
: Das Semester. Über das optionale Argument kann eine Kurzform angegeben werden.

Die Ausführungen zu `tubaf-title` treffen hier ebenso zu, außer das `\title`, `\date` und `\subtitle` vom Benutzer nicht direkt verwendet werden sollten, da diese von der Klasse überschrieben werden.


# Anmerkungen zur Implementierung

Die Klasse nutzt den `\titlefoot`-Befehl, welcher von `tubaf-title` bereitgestellt wird, um die Gesamtzahl der Seite auf der Titelseite einzufügen. Nutzen Sie `\titlefoot` nicht selbst im Dokument, da sonst die von dieser Klasse gemachten Änderungen überschrieben würden.
Die Beschriftungen der Metadaten auf der Titelseite passen sich an die Spracheinstellung von Paketen wie `babel` an.
Es werden die Sprachen `english` und `ngerman` unterstützt.
