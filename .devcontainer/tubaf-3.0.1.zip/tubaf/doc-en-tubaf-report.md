---
title: The TUBAF-Report Class
author: Max Weiner
date: 2024-04-18
---

The `tubaf-report` class is meant as a class for larger text documents like project reports, theses, seminar papers or
lecture notes, although for some of them specialized classes exist. These classes are derived from `tubaf-report` with
some additions and modifications for their specific purpose.
`tubaf-report` is itself derived from the KOMA-Script class `scrreprt` and supports all features described in
their [documentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-en.pdf).

# Usage

Load the class in your document as usual by

```latex
\documentclass{tubaf-report}
```

## Class Options

The class does support a small set of options. Further modifications are deferred to the user by using the possibilities
of KOMA-Script. Other options given are directly forwarded to `scrreport`.

`footmark=<key>`
:   Define the content of each page's foot line. Give `<key>` described in the documentation of `tubaf-marks`.

`title-black=true/false`
:  Boolean value that let the title page render in pure black and white.

## Provided Commands

This class does not provide any new commands, but those of `tubaf-title` and `tubaf-logo` are especially useful here.

# Implementation Notes

The notes given in `tubaf-title` and `tubaf-marks` also apply here.