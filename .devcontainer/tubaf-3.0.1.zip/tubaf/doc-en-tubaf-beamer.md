---
title: The TUBAF-Beamer Theme
author: Max Weiner
date: 2024-04-18
---

The `tubaf-beamer` class provides a class for presentation slides derived from the well known `beamer` class with some
additions. Also refer to
the [`beamer` documentation](http://mirrors.ctan.org/macros/latex/contrib/beamer/doc/beameruserguide.pdf).

# Usage

Use the class as usual with

```latex
\documentclass[<class-options>]{tubaf-beamer}
```

A frame aspect of 16:9 is recommended.

The `\titlegraphic` is displayed as background of the title and closing pages.
`\title` and `\subtitle` are displayed on top of this graphic, if the text is hard to read, consider to use
the `title-dark` and/or `title-graphic-opacity` options.
`\author`, `\institute` and `\date` are displayed on top of a colored trapezoid at the foot of the title page. The title
page also shows the TUBAF logo, as well as a user-chosen second logo (institute, project) supplied with `\logo`. On
normal slides a footer is rendered with frame number, author, title, the tubaf signet and the second logo.

## Class Options

The class has the following options:

`title-dark=true/false`
:   Switch the title style to dark, meaning that the main logo, title and subtitle are drawn white, as well as, the
white version of second logo is used. Especially useful if a dark title image is supplied.

`title-graphic-opacity=<value>`
:   Opacity of the title image on a white (or black, if `title-dark` is given) background. This makes the title and
subtitle text more readable on dynamic brightness images. Defaults to `0.6`.

`foot-trapezoid=true/false`
: Whether to show a light blue trapezoid at the foot of normal frames, defaults to `false`.

`foot-trapezoid-opacity=<value>`
:   Opacity of the foot trapezoid on normal frames (only shown if `foot-trapezoid=true` is given). Defaults to `0.15`.

`color-primary`
: Sets the primary color of the color palette. Defaults to `tubaf-primary`.

`color-secondary`
: Sets the secondary color of the color palette. Defaults to `tubaf-accent-11` (red).

`color-tertiary`
: Sets the tertiary color of the color palette. Defaults to `tubaf-accent-24` (light petrol).

## Provided Commands

### Document Metadata

`\speaker{<name>}`
:   Enclose the name of the speaker in `\author{}` with this command to mark him/her as the speaker by underlining. The
underlining is only shown at the title page.

`\closing{<message>}`
:   Specify a custom closing message on the closing page.

`\contact{<address>}`
:   Specify a custom contact address block on the closing page.

### Helper Macros

`\makeclosing`
:   Renders a page similar to the title page, but with a closing message on top and contact information within the
trapezoid. Both texts react on the language settings f.e. by `babel`. The message is defined as *Thank you for your
attention!* in `english` and *Vielen Dank für Ihre Aufmerksamkeit!* in `ngerman`. A custom message can be given by
the `\closing` command. The contact information block defaults to the address of the university, with the universities
name spelled in the respective language. A custom contact information block (f.e. of author and/or institute) can be
specified by the `\contact` command. There is usually enough space for 7-8 lines of text.

### Lengths

`\footsize`
: Height of the footer on normal slides. The logos therein are resized accordingly. Default size is `1cm`. Do not reduce
too much, or the author/title text will stick out the footer.

`\titlefootsize`
: Height of the foot trapezoidal on the title page. Adjust this, if the space does not fit your author/institute/date
information. Defaults to `2.5cm`.

`\closingfootsize`
: Height of the foot trapezoidal on the closing page. Adjust this, if the space does not fit your contact information.
Defaults to `4cm`.

Inherited from `tubaf-logo`, but especially useful to this class:

`\logoheadmargin`
:   Distance between upper page edge and logos on titlepage.

`\logoheadsize`
:   Height of the logos on titlepage.

# Implementation Notes

The theme does rely heavily on `beamer`'s template, color and font mechanisms to style the presentation. Styling is done
in the `beamerthemetubaf.sty` theme file. This theme does rely on mechanics introduced with this class and is therefore
not usable with the plain `beamer` class. Although, the theme is provided as a single file, there is made no distinction
in outer or inner themes.



