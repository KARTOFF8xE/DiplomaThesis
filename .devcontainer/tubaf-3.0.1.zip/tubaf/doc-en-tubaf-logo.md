---
title: The TUBAF Logo Package
author: Max Weiner
date: 2024-04-18
---

This package provides a couple of commands to draw the logo and signet of TUBAF using `tikz`.
The logos where created from SVG using [`svg2tikz`](http://xyz2tex.github.io/svg2tikz/).

All commands react on the current language setting by `babel` and draw a respective localized version, if appropriate.
The coloring of the logo can be customized by giving optional arguments to the command, which will be forwarded to the TikZ path directive.
Note, that the use of the logo is only permitted by the CD in the primary blue, black and white.
So f.e. to change the fill color to white (default is `tubaf-primary`):
```latex
\tubaflogo[fill=white]
```

# Commands for Specifying Additional Logos

`\logo{<image>}`
: Sets variable for the additonal logo (institut/working group/project aso.).

`\logowhite{<image>}`
: Sets variable for the additonal logo in pure white version (mainly intended for dark backgrounds).

`\logoblack{<image>}`
: Sets variable for the additonal logo in pure black version (mainly intended for black and white printings).

Warnings are issued if a class request a black or white version and none was specified. The default logo will then be used instead.

# Commands for TUBAF Logo and Signet

The following commands are provided. The list will be extended with logos of institutes on demand.

`\tubaflogo[<path options>]`
:   Draw the full logo with signet and TUBAF abbreviation. The text below TUBAF is localized in `english` and `ngerman`.

`\tubaflogowhite`
:   Draw the logo of TUBAF in white. Shortcut to `\tubaflogo[fill=white]`.

`\tubaflogoblack`
:   Draw the logo of TUBAF in black. Shortcut to `\tubaflogo[fill=black]`.

`\tubafsignet[<path options>]`
:   Draw the signet of TUBAF.

`\tubafsignetwhite`
:   Draw the signet of TUBAF in white. Shortcut to `\tubafsignet[fill=white]`.

`\tubafsignetblack`
:   Draw the signet of TUBAF in black. Shortcut to `\tubafsignet[fill=black]`.

![Logo Map](doc/logomap.pdf)

# Lengths

`\logoheadmargin`
:   Distance between upper page edge and logos on titlepage.

`\logoheadsize`
:   Height of the logos on titlepage.
