---
title: Das TUBAF Icons Paket
author: Max Weiner
date: 2024-04-18
---

Dieses Paket stellt Befehle zum Zeichnen von Icons in TikZ bereit.
Die generelle Struktur der Befehle ist

    \tubaficon<name>[<path options>]{<height>}{<width>}

`<name>` ist der Name des jeweiligen Icons wie unten aufgeführt. `<height>` und `<width>` sind verpflichtende Argumente zur Skalierung des Icons, diese haben dieselbe Bedeutung wie in `\resizebox{<height>}{<width>}{<content>}` aus dem `graphicx` Paket.
`<path options>` kann benutzt werden, um das Icon einzufärben (genauso wie auch im `tubaf-logo` Paket).

\begin{longtblr}[label=none]{lrlr}
\toprule
Name & Icon & Name & Icon \\
\midrule
\texttt{atom} & \tubaficonatom{1cm}{!} & &
\texttt{backwardfast} & \tubaficonbackwardfast{1cm}{!} \\
\texttt{beamer} & \tubaficonbeamer{1cm}{!} & &
\texttt{bikemen} & \tubaficonbikemen{1cm}{!} \\
\texttt{bikewomen} & \tubaficonbikewomen{1cm}{!} & &
\texttt{building} & \tubaficonbuilding{1cm}{!} \\
\texttt{calendar} & \tubaficoncalendar{1cm}{!} & &
\texttt{camera} & \tubaficoncamera{1cm}{!} \\
\texttt{cap} & \tubaficoncap{1cm}{!} & &
\texttt{check} & \tubaficoncheck{1cm}{!} \\
\texttt{chemistry} & \tubaficonchemistry{1cm}{!} & &
\texttt{chip} & \tubaficonchip{1cm}{!} \\
\texttt{clock} & \tubaficonclock{1cm}{!} & &
\texttt{close} & \tubaficonclose{1cm}{!} \\
\texttt{cloud} & \tubaficoncloud{1cm}{!} & &
\texttt{creative} & \tubaficoncreative{1cm}{!} \\
\texttt{document} & \tubaficondocument{1cm}{!} & &
\texttt{documents} & \tubaficondocuments{1cm}{!} \\
\texttt{down} & \tubaficondown{1cm}{!} & &
\texttt{electronics} & \tubaficonelectronics{1cm}{!} \\
\texttt{email} & \tubaficonemail{1cm}{!} & &
\texttt{emailalt} & \tubaficonemailalt{1cm}{!} \\
\texttt{employeesearch} & \tubaficonemployeesearch{1cm}{!} & &
\texttt{energy} & \tubaficonenergy{1cm}{!} \\
\texttt{etc} & \tubaficonetc{1cm}{!} & &
\texttt{facebook} & \tubaficonfacebook{1cm}{!} \\
\texttt{factory} & \tubaficonfactory{1cm}{!} & &
\texttt{fax} & \tubaficonfax{1cm}{!} \\
\texttt{flags} & \tubaficonflags{1cm}{!} & &
\texttt{food} & \tubaficonfood{1cm}{!} \\
\texttt{forwardfast} & \tubaficonforwardfast{1cm}{!} & &
\texttt{gearfour} & \tubaficongearfour{1cm}{!} \\
\texttt{gearhand} & \tubaficongearhand{1cm}{!} & &
\texttt{gearhuman} & \tubaficongearhuman{1cm}{!} \\
\texttt{gearthree} & \tubaficongearthree{1cm}{!} & &
\texttt{geartower} & \tubaficongeartower{1cm}{!} \\
\texttt{geartwo} & \tubaficongeartwo{1cm}{!} & &
\texttt{gearworld} & \tubaficongearworld{1cm}{!} \\
\texttt{headset} & \tubaficonheadset{1cm}{!} & &
\texttt{humans} & \tubaficonhumans{1cm}{!} \\
\texttt{instagram} & \tubaficoninstagram{1cm}{!} & &
\texttt{it} & \tubaficonit{1cm}{!} \\
\texttt{jobsearch} & \tubaficonjobsearch{1cm}{!} & &
\texttt{laptop} & \tubaficonlaptop{1cm}{!} \\
\texttt{left} & \tubaficonleft{1cm}{!} & &
\texttt{lightbulb} & \tubaficonlightbulb{1cm}{!} \\
\texttt{lightning} & \tubaficonlightning{1cm}{!} & &
\texttt{location} & \tubaficonlocation{1cm}{!} \\
\texttt{locationcircuit} & \tubaficonlocationcircuit{1cm}{!} & &
\texttt{material} & \tubaficonmaterial{1cm}{!} \\
\texttt{materialalt} & \tubaficonmaterialalt{1cm}{!} & &
\texttt{materialzoom} & \tubaficonmaterialzoom{1cm}{!} \\
\texttt{maximize} & \tubaficonmaximize{1cm}{!} & &
\texttt{metallurgy} & \tubaficonmetallurgy{1cm}{!} \\
\texttt{microscope} & \tubaficonmicroscope{1cm}{!} & &
\texttt{minerals} & \tubaficonminerals{1cm}{!} \\
\texttt{minimize} & \tubaficonminimize{1cm}{!} & &
\texttt{mining} & \tubaficonmining{1cm}{!} \\
\texttt{minus} & \tubaficonminus{1cm}{!} & &
\texttt{mobilephone} & \tubaficonmobilephone{1cm}{!} \\
\texttt{mobilephoneclick} & \tubaficonmobilephoneclick{1cm}{!} & &
\texttt{molecule} & \tubaficonmolecule{1cm}{!} \\
\texttt{monitorclick} & \tubaficonmonitorclick{1cm}{!} & &
\texttt{mountainstower} & \tubaficonmountainstower{1cm}{!} \\
\texttt{onoff} & \tubaficononoff{1cm}{!} & &
\texttt{opal} & \tubaficonopal{1cm}{!} \\
\texttt{pdf} & \tubaficonpdf{1cm}{!} & &
\texttt{pencil} & \tubaficonpencil{1cm}{!} \\
\texttt{phone} & \tubaficonphone{1cm}{!} & &
\texttt{phoneservice} & \tubaficonphoneservice{1cm}{!} \\
\texttt{pickaxe} & \tubaficonpickaxe{1cm}{!} & &
\texttt{play} & \tubaficonplay{1cm}{!} \\
\texttt{plot} & \tubaficonplot{1cm}{!} & &
\texttt{plotarrow} & \tubaficonplotarrow{1cm}{!} \\
\texttt{plotmonitor} & \tubaficonplotmonitor{1cm}{!} & &
\texttt{recycling} & \tubaficonrecycling{1cm}{!} \\
\texttt{right} & \tubaficonright{1cm}{!} & &
\texttt{robot} & \tubaficonrobot{1cm}{!} \\
\texttt{robotalt} & \tubaficonrobotalt{1cm}{!} & &
\texttt{rocket} & \tubaficonrocket{1cm}{!} \\
\texttt{running} & \tubaficonrunning{1cm}{!} & &
\texttt{stack} & \tubaficonstack{1cm}{!} \\
\texttt{studiesinterest} & \tubaficonstudiesinterest{1cm}{!} & &
\texttt{studiesoffers} & \tubaficonstudiesoffers{1cm}{!} \\
\texttt{target} & \tubaficontarget{1cm}{!} & &
\texttt{thumbup} & \tubaficonthumbup{1cm}{!} \\
\texttt{traffic} & \tubaficontraffic{1cm}{!} & &
\texttt{transparency} & \tubaficontransparency{1cm}{!} \\
\texttt{treehand} & \tubaficontreehand{1cm}{!} & &
\texttt{twitter} & \tubaficontwitter{1cm}{!} \\
\texttt{up} & \tubaficonup{1cm}{!} & &
\texttt{video} & \tubaficonvideo{1cm}{!} \\
\texttt{webcam} & \tubaficonwebcam{1cm}{!} & &
\texttt{wifi} & \tubaficonwifi{1cm}{!} \\
\texttt{windsolar} & \tubaficonwindsolar{1cm}{!} & &
\texttt{window} & \tubaficonwindow{1cm}{!} \\
\texttt{worksafety} & \tubaficonworksafety{1cm}{!} & &
\texttt{world} & \tubaficonworld{1cm}{!} \\
\texttt{youtube} & \tubaficonyoutube{1cm}{!} & &
\texttt{zoom} & \tubaficonzoom{1cm}{!} \\
\toprule
\end{longtblr}
