---
title: The TUBAF Silhouette Package
author: Max Weiner
date: 2024-04-18
---

This package provides a couple of commands to draw the silhouette of TUBAF using `tikz`.
The paths where created from SVG using [`svg2tikz`](http://xyz2tex.github.io/svg2tikz/).

The coloring of the silhouette can be customized by giving optional arguments to the command, which will be forwarded to the TikZ path directive.
So f.e. to change the fill color to white (default is `tubaf-primary`):
```latex
\tubafsilhouette[fill=white]
```

`\tubafsilhouette[<path options>]`
:   Zeichne die Silhouette in gefüllter Form mit TikZ. 

`\tubafsilhouetteline[<path options>]`
:   Zeichne die Silhouette in Konturform mit TikZ.

![Silhouette Map](doc/silhouettemap.pdf)

