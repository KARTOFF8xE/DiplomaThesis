---
title: The TUBAF-Title Package
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

This package contains the definition of a title page according to the specifications of the CI. 
The TUBAF logo and the additional `\logo` are displayed at the head and a colored trapezoid is drawn at the foot.
The title page is part of some TUBAF classes.

# Usage
The package is used like other packages:

```latex
\usepackage[<options>]{tubaf-title}
```

## Package options

`black=true/false`
: Boolean value that prints the title page in pure black and white (especially logos and trapezoid).

## Commands provided
`\title[<short>]{<long>}`
: Redefinition of `\title`, but with the option to specify a short title.

`\author[<short>]{<long>}`
: Redefinition of `\author`, but with the option to specify a short variant of the authors. 

`\titlefoot{<content>}`
: Textblock to be displayed at the foot of the title page.

`\moretitle{<content>}`
: Additional title information to be displayed below the default title block. 

`\trapezoidfootsize`
: Length that determines the height of the colored trapezoid at foot of the title page.

# Implementation Notes
The package uses `tikz` to position all objects (text, logo(s), trapezoid) on the title page.
The class redefines KOMA-Script's `\maketitle` macro to display TUBAF and additional logos as well as a colored trapezoid at the title page.
Large parts of this redefinition were just copied but adjusted to the current needs. The reimplementation should show the same behavior as the original regarding the reaction on given title texts (especially `\extratitle`, `\frontispiece`, `\uppertitleback` and `\lowertitleback`).
The new title page itself is completely drawing using `tikz`.
