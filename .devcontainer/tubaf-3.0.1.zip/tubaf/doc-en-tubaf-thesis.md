---
title: The TUBAF-Thesis Class
author: Max Weiner
date: 2024-04-18
---

The `tubaf-thesis` class is meant as a class for thesis documents, such as Bachelor's, Master's, Diploma or Doctoral
theses. The class is derived from `tubaf-report` to extend its features by a modified title page and some macros.
The title page is oriented at the requirements for doctoral theses as outlined in the doctorate regulations, but may be used for diploma, Bachelor's or Master's theses also.
`tubaf-report` is itself derived from the KOMA-Script class `scrreprt` and supports all features described in
their [documentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-en.pdf).

# Usage

Use the class in your document as usual by

```latex
\documentclass[<options>]{tubaf-thesis}
```

## Class Options

`approved=true/false`
: Whether the thesis was already approved or just submitted. Changes a few text blocks on the title page.

## Provided Commands

### Document Metadata

`\supervisor{<name>}`
:   Display the `<name>` of the supervisor at title page.

`\supervisors{<name1> \and <name2> \and ...}`
:   Display the names of the supervisors at title page. Give names divided by `\and` as usual with `\author{}`.

`\examiners{<name1> \and <name2> \and ...}`
:   Display the names of the examiners at title page. Give names divided by `\and` as usual with `\author{}`.

`\reviewers{<name1> \and <name2> \and ...}`
:   Display the names of the reviewers at title page (instead of examiners for doctoral theses). Give names divided by `\and` as usual with `\author{}`.

`\course{<name>}`
:   Display the `<name>` of the course or study program at title page.

`\faculty{<name>}`
: Display the name of the faculty the thesis is submitted to or approved by on the title page.

`\currentdegree{<degree>}`
:   Display the current academic degree of the author in front of his/her name at title page.

`\attaineddegree[<short form>]{<degree>}`
:   Display the academic degree the author attains at title page. An optional short form is typed in parentheses after the full form.

`\birthdate{<date>}`
:   Display the birthdate of the author at title page.

`\birthplace{<place>}`
:   Display the birthplace of the author at title page.

Inherited from `tubaf-logo`, but especially useful to this class:

`\logo{<image>}`
:   Use `<image>` as second logo to display at the right top of the title page (f.e. logo of institute or project).

The type of the thesis (doctoral, diploma, ...) should be defined with `\subject` to be displayed on the title page.

### Helper Macros

`\makedeclarationofauthorship[<date>]`
:   Generate a page for the mandatory Declaration of Authorship with a signature field for the author 
    (short version) and a date `<date>` beneath.
    `<date>` is optional and defaults to `\today`.

# Implementation Notes

The class uses the `\titlefoot` and `\moretitle` commands defined by `tubaf-title` to display additional metadata at the title page.
Do not use these commands yourself, since this will overwrite the changes made by this class.
The labels of the metadata displayed at the title page and the heading of the declaration of authorship will react on the language setting by packages like `babel`.
Supported languages are `english` and `ngerman`.

