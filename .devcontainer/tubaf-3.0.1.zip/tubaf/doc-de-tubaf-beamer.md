---
title: Die TUBAF-Beamer Klasse
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Die `tubaf-beamer` Klasse stellt eine Klasse für Präsentationsfolien basierend auf der bekannten `beamer` Klasse bereit.
Siehe auch die [`beamer` Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/beamer/doc/beameruserguide.pdf).

# Verwendung

Verwenden Sie die Klasse wie gewohnt mit

```latex
\documentclass[<class-options>]{tubaf-beamer}
```

Es wird ein Bildformat von 16:9 empfohlen.

Die "Titelgrafik" wird als Hintergrund der Titel- und Abschlussseiten angezeigt.
"Titel" und "Untertitel" werden über dieser Grafik angezeigt. Wenn der Text schwer zu lesen ist, sollten Sie die Optionen "darktitle" und/oder "titlegraphic-opacity" verwenden.
Autor, Institut und Datum werden über einem farbigen Trapez am Fuß der Titelseite angezeigt.
Die Titelseite zeigt auch das TUBAF-Logo sowie ein vom Benutzer gewähltes zweites Logo (Institut, Projekt), das mit `\logo` geliefert wird.
Bei normalen Folien wird eine Fußzeile mit Bildnummer, Autor, Titel, dem TUBAF-Signet und dem zweiten Logo angezeigt.

## Klassen-Optionen

Das Theme hat die folgenden Optionen:

`title-dark=true/false`
:   Schaltet den Titelstil auf dunkel um, was bedeutet, dass das Hauptlogo, der Titel und der Untertitel weiß gezeichnet werden, sowie das alternative zweite Logo verwendet wird. Besonders nützlich, wenn ein dunkles Titelbild geliefert wird.

`title-graphic-opacity=<value>`
:   Deckkraft des Titelbildes auf weißem (oder schwarzem, wenn `darktitle` angegeben ist) Hintergrund. Dies macht den Titel- und Untertiteltext auf Bildern mit dynamischer Helligkeit besser lesbar. Die Voreinstellung ist `0.6`.

`foot-trapezoid=true/false`
: Gibt an, ob am Fuß normaler Folien ein hellblaues Trapez angezeigt werden soll, der Standardwert ist `false`.

`foot-trapezoid-opacity=<value>`
: Deckkraft des Fußtrapezoids auf normalen Frames (wird nur angezeigt, wenn `foot-trapezoid=true` angegeben ist). Der Standardwert ist `0.15`.

`color-primary`
: Setzt die primäre Farbe der Farbpalette. Der Standardwert ist `tubaf-primary`.

`color-secondary`
: Setzt die sekundäre Farbe der Farbpalette. Der Standardwert ist `tubaf-accent-11` (red).

`color-tertiary`
: Setzt die tertiäre Farbe der Farbpalette. Der Standardwert ist `tubaf-accent-24` (light petrol).

## Bereitgestellte Befehle

### Dokument-Metadaten

`\speaker{<name>}`
:   Schließen Sie den Namen des Sprechers in `\author{}` mit diesem Befehl ein, um ihn durch Unterstreichung als Sprecher zu kennzeichnen.
    Die Unterstreichung wird nur auf der Titelseite angezeigt.

`\closing{<message>}`
:   Geben Sie eine benutzerdefinierte Abschlussmeldung auf der Abschlussseite an.

`\contact{<address>}`
:   Geben Sie einen benutzerdefinierten Kontaktadressenblock auf der Abschlussseite an.


### Hilfsmakros

`\makeclosing`
:   Erzeugt eine Seite ähnlich der Titelseite, aber mit einer abschließenden Nachricht im oberen Teil und Kontaktinformationen innerhalb des Trapezes.
    Beide Texte reagieren auf die Spracheinstellungen, z.B. durch `babel`.
    Die Nachricht ist definiert als *Thank you for your attention!* in `english` und *Vielen Dank für Ihre Aufmerksamkeit!* in `ngerman`.
    Eine benutzerdefinierte Nachricht kann mit dem Befehl `closing` eingegeben werden.
    Der Kontaktinformationsblock enthält standardmäßig die Adresse der Universität, wobei der Name der Universität in der jeweiligen Sprache geschrieben wird.
    Ein benutzerdefinierter Block mit Kontaktinformationen (z. B. des Autors und/oder des Instituts) kann mit dem Befehl `\contact` angegeben werden.
    In der Regel ist genug Platz für 7-8 Zeilen Text.

### Längen

`\footsize`
: Höhe der Fußzeile auf normalen Folien. Die darin enthaltenen Logos werden entsprechend verkleinert. Standardgröße ist `1cm`. Verkleinern Sie die Größe nicht zu sehr, sonst ragt der Text des Autors/Titels aus der Fußzeile heraus.

`\titlefootsize`
: Höhe des trapezförmigen Fußes auf der Titelseite. Passen Sie diesen Wert an, wenn der Platz nicht für Ihre Autor-/Instituts-/Datumsinformationen ausreicht. Der Standardwert ist 2,5 cm.

`closingfootsize`
: Höhe des trapezförmigen Fußes auf der Schlussseite. Passen Sie dies an, wenn der Platz nicht für Ihre Kontaktinformationen ausreicht. Standardwert ist `4cm`.

Geerbt von `tubaf-base`, aber besonders nützlich für diese Klasse:

`\logoheadmargin`
:   Abstand zwischen dem oberen Seitenrand und den Logos auf der Titelseite.

`\logoheadsize`
:   Höhe der Logos auf der Titelseite.

# Hinweise zur Implementierung

Das Thema stützt sich stark auf die Template-, Farb- und Schriftmechanismen von `beamer`, um die Präsentation zu gestalten.
Obwohl das Thema als eine einzige Datei bereitgestellt wird, wird nicht zwischen äußeren und inneren Themen unterschieden.