---
title: The TUBAF-Marks Package
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

This package contains the definitions for the page marks (headline and footline) common to the TUBAF document classes.

# Usage

The package is used like other packages:

```latex
\usepackage[<options>]{tubaf-marks}
```

## Package options

`footmark=<key>`
:   Define the content of each page's foot line. Give `<key>` as one of:

    - `author-title` displays the authors' names and the document title
    - `author-subject` displays the authors' names and the document subject
    - `author` displays just the authors' names
    - `none` leaves the footline blank (except for the page number)

# Implementation Notes

Page headers and footers are modified using KOMA-Script's standard `scrlayer-scrpage` mechanics, so changes there can be
overridden by the user as usual with KOMA-Script.
