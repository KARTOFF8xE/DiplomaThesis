# TUBAF LaTeX

This package provides document classes and style files for the corporate design (CD) of the Technical University Bergakademie Freiberg (TUBAF).
The document classes are based on the excellent `koma-script` classes.
There is also a class for making presentations based on `beamer`.

## Provided Functionality

The following classes are provided:

- `tubaf-article` for smaller article-like documents with sections as uppermost sectioning (based on `scrartcl`, serves equivalent purposes as standard `article`)
- `tubaf-protocol` for protocols in student's experimental courses, especially for chemistry or other sciences (based on `tubaf-article`)
- `tubaf-report` for larger report-like documents with chapters as uppermost sectioning (based on `scrreprt`, serves the same purposes as standard `report`)
- `tubaf-thesis` for theses (based on `tubaf-report`)
- `tubaf-script` for lecture notes and scripts (based on `tubaf-report`)
- `tubaf-letter` for letters (based on `scrlttr2`)
- `tubaf-beamer` for presentation slides (based on `beamer`)

The following style files are provided:

- `tubaf-color` defining the CD color palette using `xcolor`
- `tubaf-logo` defining university logo and signet drawn in `tikz`
- `tubaf-silhouette` defining university silhouette in `tikz`
- `tubaf-icons` defining icon graphics in `tikz`
- `tubaf-trapezoid` defining trapezoid style element in `tikz`
- `tubaf-fonts` defining font settings
- `tubaf-title` settings for title and title page
- `tubaf-marks` settings for marks in header and footer

The classes and styles support only a limited set of options and variants.
For faculty or institute specifics, there is a [catalogue of code snippets](https://bildungsportal.sachsen.de/opal/auth/RepositoryEntry/19727876096/CourseNode/1701746998961868011/wiki/Index) (only accessible by university members) to be pasted into the document.

## Contact

For help and further information, please contact us via the following ways:

- Mail at `latex@tu-freiberg.de`
- The forum at [OPAL](https://bildungsportal.sachsen.de/opal/auth/RepositoryEntry/19727876096) (only for university members)
- The issue tracker at [GitLab](https://gitlab.hrz.tu-chemnitz.de/tubaf-latex/tubaf-latex/-/issues) (only for university members)

The source code is hosted on the [GitLab instance of TU Chemnitz](https://gitlab.hrz.tu-chemnitz.de/tubaf-latex/tubaf-latex) (only accessible for members of TUBAF or other Saxon universities).

## Installation

## Via Your Distribution from CTAN

> This way is not available yet. Use one of the others instead.

The recommended way is to install via your TeX-distribution directly from CTAN. For `texlive` using `tlmgr` and for MikTeX using the MikTeX-Console.
See the docs of your distribution to learn how to do this.

## Manual Installation in the System

Alternatively you can install the package manually by placing the contents of the release archive in one of your `texmf` trees under `tex/latex/tubaf`.
In some Tex distributions you can add custom `texmf` paths in the config (especially MikTeX via the console).

## Manual Installation in a Project

The simplest method is to place the `*.sty` and `*.cls` files from the release archive in the root of your TeX Project.
Alternatively you can place them in a subdirectory or somewhere else and make the value of your `TEXINPUTS` environment variable point to the respective directory.
When using `latexmk`, the best way to do so is via the `latexmrc` file.

## Building the Package

> These steps are only needed to *build* the package, which is mainly aimed at developers. If you want to install the package manually, please use one of the provided release archives from CTAN or [OPAL](https://bildungsportal.sachsen.de/opal/auth/RepositoryEntry/19727876096/CourseNode/1710386968343049003).

To build the package, first create a local Python virtual environment using [`pipenv`](https://pipenv.pypa.io/)

    pipenv install

Then, run [`pytask`] within that environment to execute the full build procedure. 

    pipenv run pytask

The final package will be places in `dist/`.

### Common Issues

- On some systems the graphics library `cairo` (only Linux) is not installed. `cairo` can not be automatically installed by `pip` and must be installed via the systems package manager.
  ```
  [pipenv.exceptions.InstallError]:             Package cairo was not found in the pkg-config search path.
  [pipenv.exceptions.InstallError]:             Perhaps you should add the directory containing `cairo.pc'
  [pipenv.exceptions.InstallError]:             to the PKG_CONFIG_PATH environment variable
  [pipenv.exceptions.InstallError]:             No package 'cairo' found
  ```

## License
 
The package is distributed under the terms of the [MIT LICENSE](LICENSE).
Note that, although the package is licensed under MIT terms, the TUBAF signet, logos and other corporate design elements are protected as a trademark and their use is only permitted to university members. 
Unauthorized use, pretending to be a member of the university or to speak in behalf of the university will be prosecuted.
However, you are free to use, modify and redistribute the package or parts of it as long as you do not violate the trademark rights.
