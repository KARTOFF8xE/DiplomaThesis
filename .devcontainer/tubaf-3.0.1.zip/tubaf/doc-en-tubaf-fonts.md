---
title: The TUBAF Fonts Package
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

The TUBAF classes do not make any font settings. With this package, the main font is set to `TeX Gyre Termes`, which is similar to the well known Times New Roman. The sans font is set to `TeX Gyre Heros`, which is similar to the well known Helvetica. The original CD fonts are Futura or Arial as replacement, but here aHelvetica-like is used, because it supports more features and is better to read, while the difference is not remarkable to the non-expert user. 
The mono font is set to `TeX Gyre Cursor`.
The math font is set to `TeX Gyre Termes Math`, as it fits best to the Times and Helvetica style text fonts.

# Usage
```latex
\usepackage[<options>]{tubaf-fonts}
```

## Package Options
`sans=true`
: Set the default font to sans-serif family

# Notes on implementation

For the use of `luatex` and `xetex` compilers, the package uses the font capabilities of `fontspec`. For the `pdflatex` compiler it uses font packages (`tgtermes`, `tgheros` and `tgcursor`) to include the fonts.
