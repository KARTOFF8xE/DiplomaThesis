---
title: Die TUBAF-Thesis Klasse
author: Max Weiner
date: 2024-04-18
---

Die `tubaf-report` ist eine Klasse für große Texdokumente wie Forschungsberichte, Abschlussarbeiten, Seminararbeiten oder Vorlesungsskripte, auch wenn für einige davon spezialisierte Klassen existieren.
Diese Klassen werden von `tubaf-report` abgeleitet, um einige Erweiterungen und Modifikation vorzunehmen.
`tubaf-report` is selbst von der KOMA-Script Klasse `scrreprt` abgeleitet und unterstützt dessen komplette Funktionalität, wie in deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass{tubaf-report}
```

## Klassenoptionen

Die Klasse unterstützt einige neue Optionen. Zusätzliche Anpassungen werden dem Benutzer unter Verwendung der Möglichkeiten von KOMA-Script überlassen. Weitere Optionen werden direkt an die Klasse `scrreport` übergeben.

`footmark=<key>`
:   Legt den Inhalt der Fußzeile einer jeden Seite fest. Gültige Werte für `<key>` sind in der Dokumentation zu `tubaf-marks` beschrieben.

`title.-black=true/false`
: Lässt die Titelseite in schwarz/weiß erscheinen. 

## Bereitgestellte Befehle

### Dokument-Metadaten

Diese Klasse stellt keine neuen Befehle bereit. Die Befehle aus `tubaf-title` und `tubaf-logo` sind hier besonders nützlich.

# Anmerkungen zur Implementierung

Die Anmerkungen aus `tubaf-title` und `tubaf-marks` sind hier ebenso anzuwenden.
