---
title: Das TUBAF-Marks Paket
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Dieses Paket enthält die Definitionen für Kopf- und Fußzeile, welche von mehreren TUBAF-Klassen verwendet wird.


# Verwendung

Das Paket wird wie gewohnt geladen.

```latex
\usepackage[<options>]{tubaf-marks}
```

## Optionen

`footmark=<key>`
:   Legt den Inhalt der Fußzeile einer jeden Seite fest. Gültige Werte für `<key>` sind:

    - `author-title` setzt den Namen des/der Autoren und den Dokumenttitel in der Fußzeile
    - `author-subject` setzt den Namen des/der Autoren und die Dokumentart (`\subject`) in der Fußzeile
    - `author` setzt nur den Namen des/der Autoren in der Fußzeile
    - `none` lässt die Fußzeile frei (außer der Seitenzahl)


# Anmerkungen zur Implementierung

Kopf- und Fußzeile der Seiten wurden durchweg mit KOMA-Script's Standard `scrlayer-scrpage` Paket gesetzt, sodass diese vom Nutzer wie gewohnt angepasst werden können.

