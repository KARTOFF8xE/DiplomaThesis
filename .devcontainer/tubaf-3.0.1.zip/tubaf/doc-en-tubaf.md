---
title: The TUBAF Packages
author: Max Weiner, Markus Herbig, Dominik Kern
date: 2024-04-18
---

This is a collection of packages and classes for creating documents in the corporate design (CD) of the TU Bergakademie
Freiberg (TUBAF).

# Provided Packages

`tubaf-fonts`
: Font settings according to the CD.

`tubaf-color`
: CD color definitions.

`tubaf-logo`
: Logo and signet of TUBAF in TikZ as well as additional logos of institutes, projects, etc.

`tubaf-silhouette`
: Silhouette graphic of TUBAF in TikZ.

`tubaf-icons`
: Icon graphics of TUBAF in TikZ.

`tubaf-trapezoid`
: Trapezoid design element in TikZ.

`tubaf-title`
: Title settings common to most classes.

`tubaf-marks`
: Page mark settings common to most classes.

# Provided Classes

`tubaf-article`
: Article-like base class based on `scrartcl`.

`tubaf-report`
: Report-like base class based on `scrreprt`.

`tubaf-protocol`
: Class for experimental protocols or lab reports.

`tubaf-thesis`
: Class for thesis documents.

`tubaf-letter`
: Class for letters.

`tubaf-script`
: Class for lecture scripts or lecture notes.

`tubaf-beamer`
: Class for presentation slides.
