---
title: Das TUBAF-Schriftartenpaket
author: Max Weiner und Marcus Herbig
date: 2024-04-18
---

Die TUBAF-Klassen nehmen keine Schrifteinstellungen vor. Mit diesem Paket wird die Hauptschriftart auf `TeX Gyre Termes` gesetzt, die der bekannten Times New Roman ähnlich ist. Die serifenlose Schriftart ist auf `TeX Gyre Heros` eingestellt, die der bekannten Helvetica ähnelt. Die Original-CD-Schriftarten sind Futura oder Arial als Ersatz, aber hier wird eine Helvetica-ähnliche Schrift verwendet, weil sie mehr Funktionen unterstützt und besser zu lesen ist, während der Unterschied für den nicht-fachkundigen Benutzer nicht bemerkenswert ist. 
Die Mono-Schriftart ist auf `TeX Gyre Cursor` eingestellt.
Die mathematische Schriftart wird auf `TeX Gyre Termes Math` gesetzt, da sie am besten zu den Textschriften im Stil von Times und Helvetica passt.

# Verwendung
```latex
\usepackage[<options>]{tubaf-fonts}
```

## Paket-Optionen
`sans=true`
: Setzt die Standardschriftart auf die serifenlose Schriftfamilie

# Hinweise zur Implementierung

Für die Verwendung von `luatex` und `xetex` Compilern benutzt das Paket die Font-Fähigkeiten von `fontspec`. Für den `pdflatex`-Compiler verwendet es Schriftarten-Pakete (`tgtermes`, `tgheros` und `tgcursor`), um die Schriftarten einzubinden.