---
title: The TUBAF Script Class
author: Marcus Herbig
date: 2024-04-18
---

The `tubaf-script` is a class for all kind of course scripts. The class is derived from `tubaf-report` and extends it with a customized title page.
`tubaf-report` is itself derived from the KOMA-Script class `scrreprt` and supports its complete functionality, as described in its [documentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf).

# Usage

The class is loaded in the document as usual:

```latex
\documentclass[<options>]{tubaf-script}
```

## Class options

The class does not currently support any new options.

## Commands provided

`\module[<short>]{<module>}`
: Name of the module, the script is for. Give a short version as optional argument.

`\course[<short>]{<course>}`
: Name of the course the module belongs to. Give a short version as optional argument.

`\semester[<short>]{<semester>}`
: The semester. Give a short version as optional argument.

The notes on `tubaf-title` also apply here, except that `\title`, `\date` and `\subtitle` shall not be used by the user himself, as they are overridden by the above commands.

# Notes on the implementation

The class uses the `\titlefoot` command, which is provided by `tubaf-title`, to insert the total number of the page on the title page. Do not use `\titlefoot` yourself in the document, otherwise the changes made by this class would be overwritten.
The metadata labels on the title page adapt to the language setting of packages such as `babel`.
The languages `english` and `ngerman` are supported.