---
title: Das TUBAF-Title-Paket
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Dieses Paket beinhaltet die Definition einer Titelseite nach den Vorgaben des CI. Die Titelseite ist Bestandteil einiger tubaf-Klassen. 

# Verwendung
Das Paket wird wie andere Pakete eingebunden:

```latex
\usepackage[<options>]{tubaf-title}
```

## Paket-Optionen

`color=<color>`
: Angabe der Farbe des Logos und des Trapez'. Standard ist `tubaf-primary`

## Bereitgestellte Befehle
`\title[<short>]{<long>}`
: Redefinition von `\title`, aber mit der Option einen Kurztitel anzugeben.

`\author[<short>]{<long>}`
: Redefinition von `\author`, aber mit der Option eine Kurzvariante der Autoren anzugeben. 

`\titlefoot{<content>}`
: Textblock, welcher am Fuß der Titelseite ausgegeben wird.

`\moretitle{<content>}`
: Zusätzliche Titelinformationen, welche unterhalb des regulären Titelmaterials ausgegeben werden.

`\trapezoidfootsize`
: Länge, die die Höhe des Trapezes an der unteren Kante der Titelseite bestimmt.

# Anmerkungen zur Implementierung
Das Paket nutzt `tikz` um alle Objekte (Text, Logo(s, Trapez)) auf der Titelseite zu positionieren. 