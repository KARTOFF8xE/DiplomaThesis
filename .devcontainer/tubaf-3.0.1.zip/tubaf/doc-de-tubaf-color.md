---
title: Das TUBAF-Color Paket
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Das Paket bietet den kompletten Satz von Farben, die von der TUBAF-CD mit `xcolor` definiert wurden. Alle Farben sind als RGB, HTML und cmyk definiert.
Einige Farben sind zweimal mit unterschiedlichen Namen definiert, um die Kompatibilität mit den Namen aus dem Legacy-Paket der Version 2 zu wahren.
Es wird empfohlen, nur die neuen Namen zu verwenden, daher sind die alten hier nicht aufgeführt.

# Primäre Design-Farben

`tubaf-primary`
:   Primäre Designfarbe `0064a8` (ein mittleres Dunkelblau).

`tubaf-primary-dark`
:   Dunklere Version der primären Designfarbe `00477e`.

`tubaf-gray-<num>`
:   Verschiedene Töne von grau mit `<num>` von `10` (sehr hell) bis `90` (sehr dunkel) in Schritten von `10`. 

# Fakultätsfarben

`tubaf-geo`
:   Ein brauner Farbton für die geowissenschaftliche Fakultät `8b7530`.

`tubaf-geo-inv`
:   Eine Variante von `tubaf-geo` zur Verwendung auf dunklen Hintergründen `d5b26b`.

`tubaf-material`
:   Eine braune Einfärbung für den Fachbereich Materialwissenschaften `007b99`.

`tubaf-material-inv`
:   Eine Variante von `tubaf-material` zur Verwendung auf dunklen Hintergründen `bee2e9`.

`tubaf-energy`
:   Eine braune Einfärbung für den Fachbereich Energietechnik `b61b3d`.

`tubaf-energy-inv`
:   Eine Variante von `tubaf-energy` zur Verwendung auf dunklen Hintergründen `e4e993`.

`tubaf-environment`
:   Eine braune Einfärbung für den Fachbereich Umweltwissenschaften `0d882b`.

`tubaf-environment-inv`
:   Eine Variante von `tubaf-environment` zur Verwendung auf dunklen Hintergründen `b4d8ae`.

# Akzentfarben

`tubaf-accent-<num>`
:   Zusätzliche Akzentfarben mit `<num>` von `1` bis `30`. 

![Farbkarte](doc/colormap.pdf)