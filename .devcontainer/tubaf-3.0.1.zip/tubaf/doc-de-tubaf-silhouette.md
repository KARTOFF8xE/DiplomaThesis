---
title: Das TUBAF-Logo-Paket
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Dieses Paket bietet eine Reihe von Befehlen, um die Silhouette der TUBAF mit `tikz` zu zeichnen.
Die Pfade wurden aus SVG mit [`svg2tikz`](http://xyz2tex.github.io/svg2tikz/) erstellt.

Die Farbgebung der Silhouette kann durch optionale Argumente an den Befehl angepasst werden, die an die TikZ-Pfaddirektive weitergeleitet werden.
So kann z. B. die Füllfarbe auf weiß geändert werden (Standard ist `tubaf-primary`):
```latex
\tubafsilhouette[fill=white]
```

`\tubafsilhouette[<path options>]`
:   Draw the silhouette in filled form using tikz. Give path options to be forwarded to the path.

`\tubafsilhouetteline[<path options>]`
:   Draw the silhouette in contour line version using tikz. Give path options to be forwarded to the path.

![Silhouette Map](doc/silhouettemap.pdf)
