---
title: Die TUBAF-Article Klasse
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Die `tubaf-article` ist eine Klasse für kleinere Textdokumente.
`tubaf-article` ist selbst von der KOMA-Script Klasse `scrartcl` abgeleitet und unterstützt dessen komplette Funktionalität, wie in deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass{tubaf-article}
```
## Klassenoptionen

Die Klasse unterstützt einige neue Optionen. Zusätzliche Anpassungen werden dem Benutzer unter Verwendung der Möglichkeiten von KOMA-Script überlassen. Weitere Optionen werden direkt an die Klasse `scrreport` übergeben.

`footmark=<key>`
:   Legt den Inhalt der Fußzeile einer jeden Seite fest. Gültige Werte für `<key>` sind in der Dokumentation zu `tubaf-marks` beschrieben.

`title.-black=true/false`
: Lässt die Titelseite in schwarz/weiß erscheinen.

## Bereitgestellte Befehle

### Dokument-Metadaten

Diese Klasse stellt keine neuen Befehle bereit. Die Befehle aus `tubaf-title` und `tubaf-logo` sind hier besonders nützlich.

# Anmerkungen zur Implementierung

Die Anmerkungen aus `tubaf-title` und `tubaf-marks` sind hier ebenso anzuwenden.
