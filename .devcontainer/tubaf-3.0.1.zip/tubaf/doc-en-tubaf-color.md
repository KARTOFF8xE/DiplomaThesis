---
title: The TUBAF Color Package
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

The package provides the complete set of colors defined by the CD of TUBAF using `xcolor`. All colors are defined as RGB, HTML and cmyk.
Some colors are defined twice with different names to maintain compatibility with the names from legacy version 2 package.
It is recommended to use only the new names, therefore the old ones are not listed here.

# Primary Design Colors

`tubaf-primary`
:   Primary design color `0064a8` (a medium dark blue).

`tubaf-primary-dark`
:   Darker version of primary design color `00477e`.

`tubaf-gray-<num>`
:   Shades of gray with `<num>` from `10` (very light) to `90` (very dark) in steps of `10`. 

# Faculty Colors

`tubaf-geo`
:   A brown coloring for the geoscience faculty `8b7530`.

`tubaf-geo-inv`
:   A variant of `tubaf-geo` for use on dark backgrounds `d5b26b`.

`tubaf-material`
:   A brown coloring for the material science faculty `007b99`.

`tubaf-material-inv`
:   A variant of `tubaf-material` for use on dark backgrounds `bee2e9`.

`tubaf-energy`
:   A brown coloring for the energy engineering faculty `b61b3d`.

`tubaf-energy-inv`
:   A variant of `tubaf-energy` for use on dark backgrounds `e4e993`.

`tubaf-environment`
:   A brown coloring for the environmental science faculty `0d882b`.

`tubaf-environment-inv`
:   A variant of `tubaf-environment` for use on dark backgrounds `b4d8ae`.

# Accent Colors

`tubaf-accent-<num>`
:   Additional accent colors with `<num>` from `1` to `30`. 

![Color Map](doc/colormap.pdf)