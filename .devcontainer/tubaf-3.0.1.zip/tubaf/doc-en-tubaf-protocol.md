---
title: The TUBAF-Protocol Class
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

The `tubaf-protocol` is a class for test protocols, as they are common in the STEM field, among others. The class is
derived from `tubaf-article` and extends it with a customized title page and additional macros. `tubaf-article` itself
is derived from the KOMA script class `scrartcl` and supports all features described in
their [documentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-en.pdf).

# Useage

The class is loaded in the document as usual:

```latex
\documentclass[<options>]{tubaf-protocol}
```

## Class Options

The class does not currently support any new options.

## Commands Provided

### Document Metadata

`\supervisor{<name>}`
:   Set `<name>` as supervisor on the title page.

`\module{<name>}`
:    Set `<name>` as the module name on the title page.

`\experiment{<name>}`
: Set `<name>` as the experiment title on the title page.

`\course{<name>}`
:   Set `<name>` as the course of study on the title page.

Inherited from `tubaf-title`, but particularly useful for this class:

`\author[<short-authors>]{<authors>}`
: Authors of the document separated by `\and` as usual.

Inherited from `tubaf-logo`, but particularly useful for this class:

`\logo{<image>}`
:   Use the image `<image>` as a secondary logo, which is placed at the top right of the title page (e.g. logo of the
institute or project).

# Notes on implementation

The class uses the `\titlefoot` command, which is provided by `tubaf-title`, to insert the additional metadata into the
title page. Do not use `\titlefoot` yourself in the document, otherwise the changes made by this class would be
overwritten. The metadata labels on the title page adapt to the language setting of packages such as `babel`. The
languages `english` and `ngerman` are supported.
