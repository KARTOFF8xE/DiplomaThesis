---
title: Die TUBAF-Protocol Klasse
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Die `tubaf-protocol` ist eine Klasse für Versuchsprotokolle, wie sie unter anderen im MINT-Bereich üblich sind. Die Kalsse ist von `tubaf-article` abgeleitet und erweitert diese durch eine anpasste Titelseite und zusätzliche Makros.
`tubaf-article` is selbst von der KOMA-Script Klasse `scrartcl` abgeleitet und unterstützt dessen komplette Funktionalität, wie in deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass[<options>]{tubaf-protocol}
```

## Klassenoptionen

Die Klasse unterstützt aktuell keine neuen Optionen.

## Bereitgestellte Befehle

### Dokument-Metadaten

`\author{}` and `\date{}`

: Soll wie in anderen Dokumenten für die Authoren und das Datum genutzt werden. 

`\supervisor{<name>}`
:   Setze `<name>` als Betreuer auf der Titelseite.

`\supervisors{<name1> \and <name2> \and ...}`
:   Setze die gegebenen Namen als Betreuer auf der Titelseite. Die einzelnen Namen werden durch `\and`, wie es von  `\author{}` gewohnt ist.

`\module{<name>}`
:   Setze `<name>` als Modulnamen auf der Titelseite. 

`\experiment{<name>}` 

: Setze `<name>` als Experimenttitel auf der Titelseite.

`\course{<name>}`
:   Setze `<name>` als Studiengang auf der Titelseite.

Geerbt von `tubaf-base`, aber im besonderen nützlich für diese Klasse:

`\logo{<image>}`
:   Nutze das Bild `<image>` als Zweitlogo, welches am oberen rechten Rand der Titelseite gesetzt wird (z.B. Logo des Instituts oder Projektes).

# Anmerkungen zur Implementierung

Die Klasse nutzt den `\titlefoot`-Befehl, welcher von `tubaf-title` bereitgestellt wird, um die zusätzlichen Metadaten in die Titelseite einzufügen. Nutzen Sie `\titlefoot` nicht selbst im Dokument, da sonst die von dieser Klasse gemachten Änderungen überschrieben würden.
Die Beschriftungen der Metadaten auf der Titelseite passen sich an die Spracheinstellung von Paketen wie `babel` an.
Es werden die Sprachen `english` und `ngerman` unterstützt.
