---
title: Das TUBAF-Logo-Paket
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

Dieses Paket bietet eine Reihe von Befehlen, um das Logo und das Siegel der TUBAF mit `tikz` zu zeichnen.
Die Logos wurden aus SVG mit [`svg2tikz`](http://xyz2tex.github.io/svg2tikz/) erstellt.

Alle Befehle reagieren auf die aktuelle Spracheinstellung von `babel` und zeichnen ggf. eine entsprechend lokalisierte Version.
Die Farbgebung des Logos kann durch optionale Argumente an den Befehl angepasst werden, die an die TikZ-Pfaddirektive weitergeleitet werden.
Es sei angemerkt, dass die Benutzung des Logos und des Siegels laut CD nur in dem primären blau, weiß und schwarz gestattet ist.
So kann z. B. die Füllfarbe auf weiß geändert werden (Standard ist `tubaf-primary`):
```latex
\tubaflogo[fill=white]
```

# Befehle zur Definition von weiteren Logos

`\logo{<image>}`
:   Nutze das Bild `<image>` als Zweitlogo, welches am oberen rechten Rand der Titelseite gesetzt wird (z.B. Logo des Instituts oder Projektes).

`\logowhite{<image>}`
: Setze das Zweitlogo in einer rein weißen Variante (vornehmlich für dunkle Hintergründe).

`\logoblack{<image>}`
: Setze das Zweitlogo in einer rein schwarzen Variante (vornehmlich für schwarz/weiße Drucke).

# Befehle zur Erzeugung von Logos und Siegeln

Die folgenden Befehle werden bereitgestellt. Die Liste wird bei Bedarf um die Logos der Institute erweitert.

`\tubaflogo[<Pfadoptionen>]`
:   Zeichnet das vollständige Logo mit Signet und TUBAF-Kürzel. Der Text unter TUBAF ist in `Englisch` und `Deutsch` lokalisiert.

`\tubaflogowhite`
:   Zeichnet das Logo der TUBAF in Weiß. Kurzform für `\tubaflogo[fill=white]`.

`\tubaflogoblack`
:   Zeichnet das Logo der TUBAF in Schwarz. Kurzform für `\tubaflogo[fill=black]`.

`\tubafsignet[<Pfadoptionen>]`
:   Zeichnet das Siegel der TUBAF.

`\tubafsignetwhite`
:   Zeichnet das Siegel der TUBAF in Weiß. Kurzform für `\tubafsignet[fill=white]`.

`\tubafsignetblack`
:   Zeichnet das Siegel der TUBAF in Schwarz. Kurzform für `\tubafsignet[fill=black]`.

![Logo Map](doc/logomap.pdf)

# Längen

`\logoheadskip`
:  Freiraum zwischen oberer Seitenkante und den Logos.

`\logoheadsize`
:   Höhe der Logos.
