---
title: Die TUBAF-Letter Klasse
author: Max Weiner, Marcus Herbig
date: 2024-04-18
---

Die `tubaf-letter` ist eine Klasse für Briefe im TUBAF-Design. Die Klasse ist von der KOMA-Script-Klasse`scrlttr2` abgeleitet und unterstützt dessen komplette
Funktionalität, wie in
deren [Dokumentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf) beschrieben.

# Verwendung

Die Klasse wird im Dokument wie gewohnt geladen:

```latex
\documentclass[<options>]{tubaf-letter}
```

## Klassenoptionen

Die Klasse unterstützt keine neuen Optionen.
Optionen werden an `scrlttr` weitergereicht.

## Bereitgestellte Befehle

Die folgenden Befehle setzen die Metadaten des Briefs.
Alle sind optional, die Ausgabe wird unterdrückt, wenn einer der Befehle leer gelassen oder nicht gebraucht wird.

`\faculty{<text>}`
: Name der Fakultät oder der Einrichtung, zu welcher der Author gehört.

`\institute{<text>}`
: Name des Institutes oder der Gliederungseinheit, zu welcher der Author gehört.

`\group{<text>}`
: Name der Arbeitsgruppe, zu welcher der Author gehört.

`\processor{<text>}`
: Name des Bearbeiters.

`\room{<text>}`
: Gebäude und Raumnummer des Büros des Bearbeiters.

`\phone{<text>}`
: Telefonnummer des Bearbeiters.

`\mail{<text>}`
: E-Mail-Adresse des Bearbeiters.

`\subject{<text>}`
: Betreff des Briefes (Ausgabe in der Betreffzeile).

`\backadress{<text>}`
: Adresse für einen Antwortbrief.

`\footcontact{<adresse>}`
: Angabe der `<adresse>` in der Fußzeile. Diese wird mit der Adresse des Hauptgebäudes gefüllt, sofern keine anderen Angaben gemacht werden. 

Geerbt von `tubaf-base`, aber im besonderen nützlich für diese Klasse:

`\logo{<image>}`
:   Nutze das Bild `<image>` als Zweitlogo, welches am oberen rechten Rand der Titelseite gesetzt wird (z.B. Logo des Instituts oder Projektes).

## Anmerkungen zur Implementierung

Die `tubaf-letter` ist von der KOMA-Script-Kalsse `scrlttr2` abgeleitet, nutzt jedoch nicht deren `komavar` Mechanismus zum Setzen von Metadaten, da dieser für die meisten LaTeX-Nutzer ungewohnt ist. 
Es werden stattdessen klassische Metadaten-Befehle bereitgestellt.

## Beispiel
```latex
\documentclass{tubaf-letter}
\usepackage[sans]{tubaf-fonts}
\usepackage[english]{babel}

\begin{document}
    \logo{\includegraphics{institutslogo.png}}

    \processor{Miriam Musterfrau}
    \room{Musterbau 219}
    \phone{03731 39 0}
    \mail{miriam.musterfrau@tu-freiberg.de}
    \date{\today}

    \faculty{Wichtige Fakultät}
    \institute{Außergewöhnliches Institut}
    \group{Exzellente Arbeitsgruppe}

    \author{Miriam Musterfrau}
    \backaddress{Musterstraße 2, 09599 Freiberg}

    % ein Brief
    \begin{letter}{
        Max Mustermann    \\
        Musterstraße 1    \\
        0001 Musterstadt\\
    }
        \subject{Ein interessanter Betreff}

        \opening{Sehr geehrter Herr Mustermann,}

        Hier den Brieftext einfügen\ldots

        \closing{Mit freundlichen Grüßen}
    \end{letter}
    
    % ein weiterer Brief mit denselben Metadaten
    \begin{letter}{
        Max Mustermann    \\
        Musterstraße 1    \\
        0001 Musterstadt\\
    }
        \subject{Ein noch interessanterer Betreff}

        \opening{Sehr geehrter Herr Mustermann,}

        Noch mehr Text\ldots

        \closing{Mit freundlichen Grüßen}
    \end{letter}
\end{document}
```