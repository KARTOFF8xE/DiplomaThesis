---
title: The TUBAF-Letter Class
author: Max Weiner and Marcus Herbig
date: 2024-04-18
---

The `tubaf-letter` is a class for letters in TUBAF design. The class is derived from the KOMA script class `scrlttr2`
and supports its complete functionality, as described in described in
its [documentation](http://mirrors.ctan.org/macros/latex/contrib/koma-script/doc/scrguide-de.pdf).

# Usage

The class is loaded in the document as usual:

```latex
\documentclass[<options>]{tubaf-letter}
```

## Class options

The class does not support new options.
Other options given are forwarded to `scrlttr2`.

## Provided Commands

The following commands set metadata of the letter to be displayed in the head area. All of them are optional and will
simply be left out in the result if omitted.

`\faculty{<text>}`
: Name of the faculty or department the author belongs to.

`\institute{<text>}`
: Name of the institute or division the author belongs to.

`\group{<text>}`
: Name of the working group or subdivision the author belongs to.

`\processor{<text>}`
: Name of the processor.

`\room{<text>}`
: Building and room number of the processor's office.

`\phone{<text>}`
: Phone number of the processor.

`\mail{<text>}`
: Email address of the processor.

`\subject{<text>}`
: Subject of the letter (displayed as "Subject: ..." as a headline).

`\backadress{<text>}`
: Address for sending a reply letter. Displayed in tiny font in the address field.

`\footcontact{<address>}`
: Specification of the `<address>` in the footer.
This is filled with the address of the main building if no other information is given.

Inherited from `tubaf-base`, but particularly useful for this class:

`\logo{<image>}`
: Use the image `<image>` as a secondary logo, which is placed at the top right of the title page (e.g. logo of the
institute or project).

## Implementation Notes

The `tubaf-letter` class is based on KOMA-Script's `scrlttr2`, but does not use the `komavar` mechanism implemented
there to fill in letter's metadata, because it is unusual to most LaTeX users. Instead, classic metadata commands are
supplied for the fields that are intended to be changed by the user.

## Example
```latex
\documentclass{tubaf-letter}
\usepackage[sans]{tubaf-fonts}
\usepackage[english]{babel}

\begin{document}
    \logo{\includegraphics{institutelogo.png}}

    \processor{Miriam Musterfrau}
    \room{Musterbau 219}
    \phone{03731 39 0}
    \mail{miriam.musterfrau@tu-freiberg.de}
    \date{\today}

    \faculty{Important Department}
    \institute{Extraordinary Institute}
    \group{Excellent Group}

    \author{Miriam Musterfrau}
    \backaddress{Musterstraße 2, 09599 Freiberg}

    % a letter
    \begin{letter}{
        Max Mustermann    \\
        Musterstraße 1    \\
        0001 Musterstadt\\
    }
        \subject{An Interesting Subject}

        \opening{Dear Mr. Mustermann,}

        Your letter text goes here\ldots

        \closing{Best regards}
    \end{letter}
    
    % a second letter with same metadata
    \begin{letter}{
        Max Mustermann    \\
        Musterstraße 1    \\
        0001 Musterstadt\\
    }
        \subject{An Even More Interesting Subject}

        \opening{Dear Mr. Mustermann,}

        More Text\ldots

        \closing{Best regards}
    \end{letter}
\end{document}
```