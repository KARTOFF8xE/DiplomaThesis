---
title: Die TUBAF Pakete
author: Max Weiner, Markus Herbig, Dominik Kern
date: 2024-04-18
---

Dies ist eine Sammlung an Paketen und Klassen zur Erstellung von Dokumenten im Corporate Design (CD) der TU Bergakldemie
Freiberg (TUBAF).

# Bereitgestellte Pakete

`tubaf-fonts`
: Schrifteinstellungen nach CD.

`tubaf-color`
: Farbdefinitionen nach CD.

`tubaf-logo`
: Logo und Siegel der TUBAF sowie von Instituten, Projekten, etc.

`tubaf-silhouette`
: Grafik der Silhouette der TUBAF in TikZ.

`tubaf-icons`
: Icon-Grafiken der TUBAF in TikZ.

`tubaf-trapezoid`
: Trapez als Design Element in TikZ.

`tubaf-title`
: Gemeinsame Einstellungen zur Titelei der Klassen.

`tubaf-marks`
: Gemeinsame Einstellungen zu Kopf- und Fußzeile der Klassen.

# Bereitgestellte Klassen

`tubaf-article`
: Artikelartige Klasse basierend auf `scrartcl`.

`tubaf-report`
: Berichtsartige Klasse basierend auf `scrreprt`.

`tubaf-protocol`
: Klasse für studentische Protokolle und Laborberichte.

`tubaf-thesis`
: Klasse für studentische Arbeiten, Abschlussarbeiten und Dissertationen.

`tubaf-letter`
: Klasse für Briefe.

`tubaf-script`
: Klasse für Vorlesungsskripte.

`tubaf-beamer`
: Klasse für Folien zu Vorträgen und Vorlesungen.
